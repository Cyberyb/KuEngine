# UI 与性能统计设计

核对日期：2026-10-24（REQ-16 侧栏补充；B实例/slot编辑与Clear及统计口径保持）。

源码：[UIOverlay](../../src/KuEngine/UI/UIOverlay.h)、[Engine::render](../../src/KuEngine/Core/Engine.cpp)、[CommandList](../../src/KuEngine/RHI/CommandList.cpp)。

## UI 所有权

Engine 持有单个 UIOverlay。UIOverlay 创建 ImGui Context、GLFW/Vulkan Backend、DescriptorPool，唯一拥有 `SidebarState` 和 `SidebarLayoutPolicy`；提供 newFrame、render、右侧栏绘制和交换链 imageCount 更新。析构时关闭 Backend 和 Context。

Pass::drawUI 只构建业务参数内容；RenderPipeline 分别提供 Pass 内容和 Graph 调试内容，逐 Pass 以索引 `PushID` 隔离控件 ID。UIOverlay 将它们放进唯一右侧栏的 Performance、Parameters / Scene、Render Graph 区段，避免多个浮动窗口或 Alpha Pass 同名控件冲突。Render 模块目前直接依赖 ImGui。

Mclaren 的 Parameters / Scene 内另有 Model 与 HDR 区块：各自显示 Draft 路径、Load 按钮、Active 路径、generation、状态/分类和错误。Load 只将路径复制为不可变请求并禁用并发请求；它不在 ImGui 回调中读取文件、上传或销毁 GPU 对象。请求会在下一次可用的 Pass update 安全点处理，成功后刷新 Active/generation，失败时 Draft/状态可见而已发布的画面、统计和相机保持。

Mclaren显示共享mesh/variant/draw/贴图数量；Material区提供Instance与Material Slot选择、所选实例Position/Rotation(deg)/Scale、所选slot的BaseColor/Metallic/Roughness/Emissive/PBR-Unlit。UI列出该slot影响的primitive：同实例同槽联动，其他实例/槽不变。base RGBA/metallic/roughness范围[0,1]，emissive RGB[0,64]；Unlit禁用metallic/roughness但保留值，返回PBR恢复。Global tint仍影响全场景，不是独立slot编辑。ForwardReuse的预设/实例信息不替代最终Mclaren操作。

编辑仅排队CPU请求，pending期间禁用并发编辑/资产操作；下一Fence-safe update完成candidate校验、管线与全phase容量准备后发布。路径/resize/recompile保留编辑和选中实例/slot，成功模型替换才重置选择。它是示例编辑UI，公共SceneMaterialSlot不依赖ImGui，不是通用编辑器。HDR区独立Clear Environment按钮不等于空路径Load或关闭贡献；完整黑GPU候选成功后Active HDR清空、generation增长、sky/env关闭，Load可再次恢复。错误Draft/status仍可见，失败保留已发布状态。

UIOverlay::render 调用 ImGui::Render 和 Vulkan Backend。UI depth format 为 `VK_FORMAT_UNDEFINED`；Overlay 在 Display CLEAR/STORE 后对 SwapChainColor 使用 LOAD/read-write，实际附件由 RenderPipeline::executeOverlay 管理。

## 帧内调用位置

```text
UIOverlay::newFrame
→ RenderPipeline::update
→ UIOverlay::drawSidebar（Pass / Graph 内容）
→ RenderPipeline::execute（post-UI ScenePrepare snapshot → HDR场景 → 唯一Display）
→ RenderPipeline::executeOverlay
→ UIOverlay::render（生成 DrawData 并记录 ImGui 命令）
```

`describeSidebarFrame`在帧初捕获布局、区段和宽度，同时决定ViewerLayout/输入排除/本帧侧栏，收展下一帧生效。展开保留侧栏宽度，收起为紧凑统计，隐藏后保留重开控件；小窗可滚动、过窄回退覆盖。当前Engine只在Graph前drawSidebar一次，显示最近completed-submit统计；Graph后executeOverlay调用UI render，不再重建侧栏。

## UIFrameStatistics 数据契约

UI在普通Display或直接MRT GBufferDisplay编码之后，参数先进入post-UI snapshot。Rendering的Render Path/GBuffer View只请求CPU状态，下一Fence-safe Source update发布mask；Forward禁用GBuffer并解释，debug→Forward恢复Scene，无Deferred能力提示原因。八视图见 [Deferred](13-deferred-rendering.md)。普通SRGB硬件恒编码/gamma禁用，debug固定单次编码、不受曝光/tone/Blend变化。B的实例编辑/真实Clear同样排队安全发布。普通ForwardReuse9/45或10/48、默认Mclaren91/9202884或92/9202887；debug替换一个Display，计数不变，多实例fixture/Clear/test probes按实际构成计数。

`drawSidebar` 内部的统计内容接收 `UIFrameStatistics`，UI 只显示传入数据，不自行计算帧时间。

| 显示项 | 数据来源 | 当前含义 |
|---|---|---|
| FPS | Engine deltaTime 倒数 | 主循环相邻时间点的瞬时帧率 |
| Frame | deltaTime × 1000 | 主循环帧间隔，包含等待/呈现等影响 |
| CPU | Engine acquire 成功后到 submit 返回的墙钟差 | 最近完成提交；含 UI、更新、命令记录和提交 |
| GPU | CommandList 两个 Timestamp Query | 同一最近完成提交的主命令缓冲执行跨度，含 UI 和布局转换 |
| Draw Calls | CompletedFrameStatistics | 同一最近完成提交中 draw/drawIndexed 记录的业务命令数 |
| Vertices | CompletedFrameStatistics | 同一最近完成提交中 vertexCount 或 indexCount 乘 instanceCount 的总和 |

CPU 不含事件轮询、Fence/acquire 等待与 present；也不是进程 CPU 利用率或纯线程运行时间。GPU 不含显示器刷新延迟，可能包含时间戳范围内的 GPU 调度/同步停顿。两个指标不能直接相加当作 Frame。

## 可用性与显示限制

- FPS/Frame 标注 current main-loop sample；CPU/GPU/Draw Calls/Vertices 标注 same completed submit，首个完成快照前显示 waiting/N/A。
- GPU `Unsupported` 表示没有 Timestamp 能力，`Waiting` 表示支持但尚无可读查询，`Available` 才显示毫秒值。
- GPU 在 Fence 后读取 availability，避免用本帧尚未执行的 Query；有限帧结束在 device idle 后也会尝试完成 pending 快照。
- ImGui 内部 draw 不计入业务 Draw Calls/Vertices，但它的 GPU 命令包含在 GPU 时间内。
- 索引提交数量并不等于去重模型顶点数；Mclaren 控制面板中的 Mesh Vertices 是另一种资源容量统计。
- showStats=false 只隐藏面板，当前代码仍执行计数和计时。
- 当前没有时间平滑、历史曲线、CSV 导出、每 Pass GPU Query 或自动性能回归。

## 交互边界

ImGui Backend 使用 GLFW 回调接入；滚轮由 Input 的 GLFW 回调累计。`SceneInteractionGate` 只允许活动窗口中、未被 ImGui 捕获且位于 `ViewerLayout.sceneLogical`（并排除覆盖 UI）内的按下开始拖动或消费滚轮；已开始的场景拖动可持续至松开。Input 在 attach、失焦、恢复、最小化/resize 跳帧等连续性中断时推进 epoch 并清空/抑制边缘，Gate 因而不会恢复陈旧拖动。

Mclaren 的 FreeFly 在此基础上还要求右键场景焦点：`WantCaptureKeyboard`、`WantTextInput`、鼠标捕获或窗口/场景失效会取消焦点；切换模式、重置和 epoch 改变后必须等待无按键/无鼠标按下的中性样本。这样侧栏编辑文本、UI 操作和失焦不会驱动 WASDQE。Cube 仍只使用左键 OrbitInspect 语义。当前只有单 Context，未建立多窗口 UI 管理；自由相机仍为 Mclaren 示例层功能。

## CornellBox 参数与统计

2026-10-21 新示例复用唯一侧栏和 path/GBuffer 控件：Ceiling light [0,3] 仅缩放四点光，Exposure [.1,3]，Neutral fill [0,.5]；Material 选择短/高盒，独立 Roughness [.04,1]、Metallic [0,1]；Camera yaw [-16,16]°、pitch [-12,12]°、distance [3.2,5.5]，Reset view 恢复 0/0/4.1。参数进入本帧 post-UI snapshot；路径请求下一 Fence-safe update 生效，切换/resize/recompile 保留编辑。相机没有新增鼠标 Orbit/FreeFly。

普通 Deferred 10 draws/114 submitted vertices，Forward 9/111；Prepare/空 Blend/可选 transfer 读回不产生 draw，ImGui 继续不计入业务统计。两盒独立 M/R、灯强、曝光、Base/Normal/Roughness/Metallic/ShadingModel/Scene、路径保留、相机和侧栏收展均由独立 QA 实际 GUI 观察，见 [CornellBox](../usage/cornell-box-example.md)。其余八视图映射延用公共实现，不把本轮观察扩成八视图全部重验。

## VolumetricIntegration 参数与统计（2026-10-24）

ScenePass 复用唯一侧栏：Pause、Time [0,60] 秒、四种 Integration（split 左 basic/右 analytical）、Fog density [0,5]、Strong height fog [0,10]、Light intensity [0,5]、View steps [16,256]、Shadow steps [1,64]、Fog noise、Volumetric shadows 和 Reset reference defaults。UI 范围与 CLI 可不同，CLI 精确范围见 [使用说明](../usage/volumetric-integration-example.md)。Reset 恢复 time=0/动画、analytical、density/light=1、strongFog=0、100/16 步、noise/shadows 开启。固定相机不响应 Orbit/FreeFly 或原作 iMouse。

CPU Settings 在本帧 UI 后以 push constants 记录到 ScenePass；Display 使用本槽 descriptor，参数不写共享 GPU UBO。两个全屏三角形合计 2 draws / 6 vertices，可选读回为 0/0，UI 统计口径不变。场景投影使用 sceneFramebuffer 比例，侧栏收展不拉伸球形介质。独立 QA 实际操作了暂停/时间、全部积分模式、密度/强雾/光、noise/shadows/reset 与侧栏收展，并验证应用正常退出；本包 [QA 证据](../../build/qa-volumetric-integration/qa-report.md) 不替代 M5 或其他示例整体验收。
