KuEngine build cleanup archive — 2026-10-30

Original build directory: 110,733,644,481 bytes (103.129 GiB), 57,386 files.
Entries retain original repository-relative paths, including the build/ prefix.
Included: reports, logs, manifests, probe scripts/sources, screenshot evidence,
small ROI/matrix checks and the original XlBSRz GLSL/metadata/matching records.
Excluded: executables, debug/object/static library files, installed dependencies,
copied binary models/HDR assets, raw full-frame readbacks and dataset.zip.
Large pixel data referenced by historical reports has been intentionally deleted.
Preserved reports describe past runs; no build, GPU test or acceptance was rerun.
This is evidence preservation, not a runnable build or complete build backup.
Extract into a separate directory to inspect. Do not overwrite current sources.
BUILD-CLEANUP.json lists preserved paths, byte sizes and SHA256 hashes.
BUILD-INVENTORY.json records all original paths and logical byte sizes.
